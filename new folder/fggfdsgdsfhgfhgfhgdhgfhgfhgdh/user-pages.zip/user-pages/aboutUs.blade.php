@extends('layouts.dashboard')

@section('title', 'Tentang Kami')

@section('content')
    {{-- Tambahkan Google Icons jika belum --}}
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <section class="bg-white py-16">
        <div class="max-w-6xl mx-auto px-6">
            <div class="text-center mb-10">
                <div class="flex justify-center items-center gap-2 mb-4">
                    <span class="material-icons text-blue-600 text-3xl">info</span>
                    <h2
                        class="inline-block text-sm font-bold uppercase tracking-widest bg-blue-100 text-blue-800 px-4 py-1 rounded-full">
                        Tentang Kami
                    </h2>
                </div>
                <h1 class="text-4xl font-extrabold text-gray-900">Visi, Misi, dan Profil Perusahaan</h1>
                <p class="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
                    Kenali lebih dekat tujuan kami dan komitmen dalam melayani kebutuhan perjalanan Anda.
                </p>
            </div>

            <div class="text-gray-700 space-y-8 leading-relaxed max-w-4xl mx-auto">
                <div class="bg-blue-50 p-6 rounded-lg shadow-lg border-l-4 border-blue-600">
                    <h3 class="text-xl font-semibold text-gray-900 mb-4">Visi</h3>
                    <p class="text-lg">
                        Menjadi platform pemesanan tiket terpercaya dan terdepan di Indonesia yang memberikan kemudahan,
                        kenyamanan, dan keamanan dalam setiap perjalanan.
                    </p>
                </div>

                <div class="bg-green-50 p-6 rounded-lg shadow-lg border-l-4 border-green-600">
                    <h3 class="text-xl font-semibold text-gray-900 mb-4">Misi</h3>
                    <ul class="list-disc list-inside space-y-2 text-lg">
                        <li>Menyediakan layanan pemesanan tiket yang cepat, mudah, dan terjangkau.</li>
                        <li>Memberikan pengalaman pengguna yang terbaik melalui teknologi terkini.</li>
                        <li>Membangun kemitraan strategis dengan maskapai dan penyedia transportasi.</li>
                        <li>Menjamin keamanan transaksi dan data pelanggan.</li>
                    </ul>
                </div>

                <div class="bg-yellow-50 p-6 rounded-lg shadow-lg border-l-4 border-yellow-600">
                    <h3 class="text-xl font-semibold text-gray-900 mb-4">Profil Perusahaan</h3>
                    <p class="text-lg">
                        Kami adalah platform digital yang melayani pemesanan tiket pesawat, kereta, dan transportasi lainnya
                        secara online. Didirikan dengan tujuan untuk memudahkan masyarakat dalam merencanakan perjalanan,
                        kami
                        hadir dengan sistem yang handal, tim dukungan pelanggan yang responsif, dan berbagai pilihan metode
                        pembayaran yang aman. Komitmen kami adalah menjadi mitra perjalanan terbaik Anda.
                    </p>
                </div>
            </div>
        </div>
    </section>
@endsection
